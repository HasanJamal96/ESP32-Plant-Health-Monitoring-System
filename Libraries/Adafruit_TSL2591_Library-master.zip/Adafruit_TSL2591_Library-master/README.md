# Adafruit TSL2591 Library [![Build Status](https://travis-ci.com/adafruit/Adafruit_TSL2591_Library.svg?branch=master)](https://travis-ci.com/adafruit/Adafruit_TSL2591_Library)

<img src="https://cdn-shop.adafruit.com/970x728/1980-07.jpg" height="300"/>

This is an Arduino library for the TSL2591 digital luminosity (light) sensors. 

Pick one up at http://www.adafruit.com/products/1980

You'll also need the Adafruit_Sensor library from https://github.com/adafruit/Adafruit_Sensor
